/**
 * Node_3
 */
public class Node_3 {

    Node_3 next3, prev3;
    int pembeli3;

    public Node_3 (Node_3 prev3, int pembeli3, Node_3 next3){
        this.next3 = next3;
        this.pembeli3 = pembeli3;
        this.prev3 = prev3;

    }
}