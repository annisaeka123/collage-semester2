/**
 * Pesanan_3
 */
public class Pesanan_3 {

    int kodePesanan3;
    String namaPesanan3;
    int harga3;

    public Pesanan_3(int a3, String b3, int d3) {
        kodePesanan3 = a3;
        namaPesanan3 = b3;
        harga3 = d3;
    }
}