public class Pembeli_3 {
    String namaPembeli3, NoHp3;

    public Pembeli_3(String b3, String c3) {
        namaPembeli3 = b3;
        NoHp3 = c3;
    }
}